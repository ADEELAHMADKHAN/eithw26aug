//
//  Constants.swift
//  FoodItems
//
//  Created by Cosultant on 8/26/22.
//

import UIKit
import Foundation

struct Images {
    static let KabobWithRice = UIImage(named: "15-food-items-you-must-serve-at-a-bengali-wedding-mochar-chop-veg.jpeg")!
    static let Pizza = UIImage(named: "1610716314_untitled-design-2021-01-15t184025.049.jpeg")!
    static let Donuts = UIImage(named: "adhd-foods-to-avoid_thumb-732x549.jpeg")!
    static let CurlyFries = UIImage(named: "AN112-Curly-Fries-Close-Up-732x549-thumb.jpeg")!
//    static let BurgerWithFries = UIImage(named: "Foods_to_avoid_during_summers.jpeg")!
    static let Samosas = UIImage(named: "images.jpeg")!
    static let Shawarma = UIImage(named: "maxresdefault.jpeg")!
    static let NachosFries = UIImage(named: "nacho_fries_courtesy-tacobell.com_.jpeg")!
    static let Noodles = UIImage(named: "noodles_480x480.jpeg")!
    static let Salad = UIImage(named: "panera-greek-salad-1613148929.jpeg")!
}



