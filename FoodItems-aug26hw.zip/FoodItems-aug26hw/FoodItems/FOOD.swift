//
//  FOOD.swift
//  FoodItems
//
//  Created by Cosultant on 8/26/22.
//

import UIKit
struct FOOD {
    var image:UIImage
    var title:String 
}
