//
//  FoodTableViewCell.swift
//  FoodItems
//
//  Created by Cosultant on 8/26/22.
//

import UIKit

class FoodTableViewCell:UITableViewCell{
 var FoodImageView = UIImageView()
 var FoodTitle = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier )
        addSubview(FoodImageView)
        addSubview(FoodTitle)
        configureImageView()
        configureTitleLabel()
        setImageConstraints()
        setTitleLableConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func set(_ food: FOOD ){
        FoodImageView.image = food.image
        FoodTitle.text = food.title
    }
    
    func configureImageView(){
        FoodImageView.layer.cornerRadius = 10
        FoodImageView.clipsToBounds = true
    }
    
    func configureTitleLabel(){
        FoodTitle.numberOfLines = 0
        FoodTitle.adjustsFontSizeToFitWidth = true
    }
    
    func setImageConstraints(){
        FoodImageView.translatesAutoresizingMaskIntoConstraints = false
        FoodImageView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        FoodImageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12).isActive = true
        FoodImageView.widthAnchor.constraint(equalTo: FoodImageView.heightAnchor, multiplier: 16/9).isActive = true
        FoodImageView.heightAnchor.constraint(equalToConstant: 100).isActive = true
    }
    
    func setTitleLableConstraints(){
        FoodTitle.translatesAutoresizingMaskIntoConstraints = false
        FoodTitle.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        FoodTitle.leadingAnchor.constraint(equalTo: FoodImageView.trailingAnchor , constant: 20).isActive = true
        FoodTitle.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12).isActive = true
      //FoodTitle.widthAnchor.constraint(equalTo: FoodTitle.heightAnchor, multiplier: 16/9).isActive = true
        FoodTitle.heightAnchor.constraint(equalToConstant: 80 ).isActive = true
    }
}
