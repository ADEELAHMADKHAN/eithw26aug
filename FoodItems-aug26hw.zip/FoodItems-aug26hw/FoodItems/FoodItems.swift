//
//  ViewController.swift
//  FoodItems
//
//  Created by Cosultant on 8/25/22.
//

import UIKit

class FoodItems: UIViewController {

    var tableView = UITableView()
    var foods:[FOOD] = []
    let foodCell = "foodCell"
    
    
    
    override func viewDidLoad() {
        view.backgroundColor = .green
        title = "Delecious Food Items"
        configureTableView()
        setTableViewDelegates()
        foods = fetchData()
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func configureTableView() {
        view.addSubview(tableView)
        tableView.rowHeight = 100
        tableView.register(FoodTableViewCell.self , forCellReuseIdentifier: foodCell)
        tableView.pin(view)
    }
    
    func setTableViewDelegates(){
        tableView.delegate = self
        tableView.dataSource = self
    }


}

extension FoodItems: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return foods.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: foodCell) as! FoodTableViewCell
        let food = foods[indexPath.row]
        cell.set(food)
        return cell
    }
}
 
extension FoodItems{
    func fetchData() -> [FOOD] {
        let foods = [ //FOOD(image:Images.BurgerWithFries, title: "Burger With Fries"),
                      FOOD(image:Images.CurlyFries, title: "CurlyFries"),
                      FOOD(image:Images.Donuts, title: "Donuts"),
                      FOOD(image:Images.KabobWithRice, title: "KabobWithRice" )]
    
       
    return foods
}

}
