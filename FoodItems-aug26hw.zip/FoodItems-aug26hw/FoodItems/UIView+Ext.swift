//
//  UIView+Ext.swift
//  FoodItems
//
//  Created by Cosultant on 8/26/22.
//

import UIKit
// helper to setup AutoLayout Constraints Programmatically

extension UIView {
func pin(_ superView:UIView){
     translatesAutoresizingMaskIntoConstraints = false
     topAnchor.constraint(equalTo: superView.topAnchor).isActive = true
     leadingAnchor.constraint(equalTo: superView.leadingAnchor).isActive = true
     trailingAnchor.constraint(equalTo: superView.trailingAnchor).isActive = true
     bottomAnchor.constraint(equalTo: superView.bottomAnchor).isActive = true
     
    
}
}
